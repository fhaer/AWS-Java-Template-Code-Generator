package de.test.clientutil;

import java.util.Properties;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;

public class ClientUtil {
	private static InitialContext initialContext;

	private static final String PKG_INTERFACES = "org.jboss.ejb.client.naming";

	public static InitialContext getInitialContext() throws NamingException {
		if (initialContext == null) {
			Properties properties = new Properties();
			//properties.put(Context.URL_PKG_PREFIXES, PKG_INTERFACES);
			properties.setProperty("java.naming.factory.initial",
	                "com.sun.enterprise.naming.SerialInitContextFactory");
			properties.setProperty("java.naming.factory.url.pkgs",
	                "com.sun.enterprise.naming");
			properties.setProperty("java.naming.factory.state",
	                "com.sun.corba.ee.impl.presentation.rmi.JNDIStateFactoryImpl");
	 
	        // Should not be necessary for local test (default values), but
	        // currently is
			properties.setProperty("org.omg.CORBA.ORBInitialHost", "localhost");
	        properties.setProperty("org.omg.CORBA.ORBInitialPort", "3700");
	 
			initialContext = new InitialContext(properties);
		}
		return initialContext;
	}

}
