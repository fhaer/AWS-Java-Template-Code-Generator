package de.test.client;

import javax.naming.InitialContext;
import javax.naming.NameClassPair;
import javax.naming.NamingEnumeration;
import javax.naming.NamingException;

import de.test.SB;
import de.test.SB2Remote;
import de.test.SessionBeanBizLogicRemote;
import de.test.clientutil.ClientUtil;

public class TestClient {
	public static void main(String[] args) {
		SessionBeanBizLogicRemote bean = (SessionBeanBizLogicRemote) doLookup("SessionBeanBizLogic");
		System.out.println(bean.sayHello()); // 4. Call business logic
		SB2Remote bean2 = (SB2Remote) doLookup("SB2");
		bean2.setState("absrttkj");
		System.out.println(bean2.getState()); // 4. Call business logic
	}

	private static SB doLookup(String name) {
		InitialContext context = null;
		SB bean = null;
		try {
			// 1. Obtaining Context
			context = ClientUtil.getInitialContext();
			// 2. Generate JNDI Lookup name
			String lookupName = getLookupName();
			// 3. Lookup and cast
			//printContextNames(context);
			bean = (SB) context.lookup("java:global/EjbTest2/" + name);

		} catch (NamingException e) {
			e.printStackTrace();
		}
		return bean;
	}

	private static void printContextNames(InitialContext context) {
		NamingEnumeration<NameClassPair> list;
		try {
			list = context.list("eclipseApps/EjbTestEAR/");
			while (list.hasMore()) {
				  System.out.println(list.next().getName());
			}
		} catch (NamingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	private static String getLookupName() {
		/*
		 * The app name is the EAR name of the deployed EJB without .ear suffix.
		 * Since we haven't deployed the application as a .ear, the app name for
		 * us will be an empty string
		 */
		String appName = "EjbTestEAR";

		/*
		 * The module name is the JAR name of the deployed EJB without the .jar
		 * suffix.
		 */
		String moduleName = "EjbTest";

		/*
		 * AS7 allows each deployment to have an (optional) distinct name. This
		 * can be an empty string if distinct name is not specified.
		 */
		String distinctName = "";

		// The EJB bean implementation class name
		String beanName = ""; //SessionBeanBizLogic.class.getSimpleName();

		// Fully qualified remote interface name
		final String interfaceName = SessionBeanBizLogicRemote.class.getName();

		// Create a look up string name
		String name = "ejb:" + appName + "/" + moduleName + "/" + distinctName
				+ "/" + beanName + "!" + interfaceName;

		// Create a look up string name
		name = "ejb:" + appName + "/" + moduleName + "/" + beanName
				+ "!" + interfaceName;

		return name;
	}
}
