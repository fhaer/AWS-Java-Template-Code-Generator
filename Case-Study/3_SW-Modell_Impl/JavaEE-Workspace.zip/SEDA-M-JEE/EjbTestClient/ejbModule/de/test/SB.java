package de.test;

public interface SB {

}
