package de.test;

import javax.ejb.Remote;

@Remote
public interface BizLogicBeanRemote {
	public String sayHello();
}
