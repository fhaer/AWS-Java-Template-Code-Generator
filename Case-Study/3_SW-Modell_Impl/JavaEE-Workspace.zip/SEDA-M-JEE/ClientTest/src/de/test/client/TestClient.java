package de.test.client;

import java.util.Properties;

import javax.naming.InitialContext;
import javax.naming.NameClassPair;
import javax.naming.NamingEnumeration;
import javax.naming.NamingException;

import de.test.SB2Remote;
import de.test.SessionBeanBizLogicRemote;

public class TestClient {
	
	public final static String HOSTNAME = "felix-pc";
	public final static String PORT = "3700";
	
	public static void main(String[] args) {
		TestClient t = new TestClient();
		t.start();
	}

	public void start() {
		try {
			InitialContext initialContext = getInitialContext();
			// printContextNames(initialContext);
			SessionBeanBizLogicRemote bean = (SessionBeanBizLogicRemote) initialContext
					.lookup("de.test.SessionBeanBizLogicRemote");
			System.out.println(bean.sayHello());
			SB2Remote bean2 = (SB2Remote) initialContext
					.lookup("de.test.SB2Remote");
			bean2.setState("absrttkj");
			System.out.println(bean2.getState());
		} catch (NamingException e) {
			e.printStackTrace();
		}
	}

	private InitialContext getInitialContext() {
		Properties properties = new Properties();
		properties.setProperty("java.naming.factory.initial",
				"com.sun.enterprise.naming.SerialInitContextFactory");
		properties.setProperty("java.naming.factory.url.pkgs",
				"com.sun.enterprise.naming");
		properties.setProperty("java.naming.factory.state",
				"com.sun.corba.ee.impl.presentation.rmi.JNDIStateFactoryImpl");
		properties.setProperty("org.omg.CORBA.ORBInitialHost", HOSTNAME);
		properties.setProperty("org.omg.CORBA.ORBInitialPort", PORT);

		Properties systemProperties = System.getProperties();
		for (Object keyObject : properties.keySet()) {
			String key = (String) keyObject;
			String value = properties.getProperty(key);
			systemProperties.setProperty(key, value);
		}
		System.setProperties(systemProperties);
		
		InitialContext initialContext = null;
		try {
			initialContext = new InitialContext();
			for (Object keyObject : properties.keySet()) {
				String key = (String) keyObject;
				String value = properties.getProperty(key);
				initialContext.addToEnvironment(key, value);
			}
		} catch (NamingException e) {
			e.printStackTrace();
		}
		return initialContext;
	}

	private void printContextNames(InitialContext context) {
		NamingEnumeration<NameClassPair> list;
		try {
			list = context.list("");
			while (list.hasMore()) {
				System.out.println(list.next().getName());
			}
		} catch (NamingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	private static String getLookupName() {
		/*
		 * The app name is the EAR name of the deployed EJB without .ear suffix.
		 * Since we haven't deployed the application as a .ear, the app name for
		 * us will be an empty string
		 */
		String appName = "EjbTestEAR";

		/*
		 * The module name is the JAR name of the deployed EJB without the .jar
		 * suffix.
		 */
		String moduleName = "EjbTest";

		/*
		 * AS7 allows each deployment to have an (optional) distinct name. This
		 * can be an empty string if distinct name is not specified.
		 */
		String distinctName = "";

		// The EJB bean implementation class name
		/*
		 * String beanName = SessionBeanBizLogic.class.getSimpleName();
		 * 
		 * // Fully qualified remote interface name final String interfaceName =
		 * SessionBeanBizLogicRemote.class.getName();
		 * 
		 * // Create a look up string name String name = "ejb:" + appName + "/"
		 * + moduleName + "/" + distinctName + "/" + beanName + "!" +
		 * interfaceName;
		 * 
		 * // Create a look up string name name = "ejb:" + appName + "/" +
		 * moduleName + "/" + beanName + "!" + interfaceName;
		 */
		return "";
	}
}
