package de.test.entities;

import java.io.Serializable;
import java.lang.String;
import javax.persistence.*;

/**
 * Entity implementation class for Entity: JPAEntity
 *
 */
@Entity

public class JPAEntity implements Serializable {

	
	private String field;   
	@Id
	private int id;
	private static final long serialVersionUID = 1L;

	public JPAEntity() {
		super();
	}   
	public String getField() {
		return this.field;
	}

	public void setField(String field) {
		this.field = field;
	}   
	public int getId() {
		return this.id;
	}

	public void setId(int id) {
		this.id = id;
	}
   
}
