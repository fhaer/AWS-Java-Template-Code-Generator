package de.test;

import javax.ejb.Remote;
import javax.jws.WebService;

@Remote
public interface SessionBeanBizLogicRemote extends SB {
	 public String sayHello();
}
