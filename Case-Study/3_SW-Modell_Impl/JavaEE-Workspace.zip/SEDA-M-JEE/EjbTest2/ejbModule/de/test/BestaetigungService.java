package de.test;

public class BestaetigungService {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

	public void bestaetigung() {
		// TODO Auto-generated method stub
		
	}

}
