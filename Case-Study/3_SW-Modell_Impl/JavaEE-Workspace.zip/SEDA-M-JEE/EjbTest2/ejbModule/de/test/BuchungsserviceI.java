package de.test;

public class BuchungsserviceI {

	public void bestaetigung() {
		// TODO Auto-generated method stub
		
	}

}
