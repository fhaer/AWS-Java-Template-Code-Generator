package de.test;

import javax.ejb.Remote;

@Remote
public interface BereitstellungsserviceI {
	 public void anfrage(Bereitstellung b);
}
