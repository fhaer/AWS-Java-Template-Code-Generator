package de.test;

public class AnfrageService {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

	public void anfrage(Bereitstellung b) {
		// TODO Auto-generated method stub
		
	}

}
