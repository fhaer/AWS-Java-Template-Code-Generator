package de.test;

import javax.ejb.Stateful;

@Stateful
public class Bereitstellungsservice implements BereitstellungsserviceI {

	BuchungsserviceI buchungsservice;
	
	private AnfrageService anfrageService;
	private BestaetigungService bestaetigungService;
	
    public Bereitstellungsservice() {
        // default constructor (required)
    }

	@Override
	public void anfrage(Bereitstellung b) {
		anfrageService.anfrage(b);
		bestaetigung();
	}
	
	private void bestaetigung() {
		bestaetigungService.bestaetigung();
		buchungsservice.bestaetigung();
	}
}
