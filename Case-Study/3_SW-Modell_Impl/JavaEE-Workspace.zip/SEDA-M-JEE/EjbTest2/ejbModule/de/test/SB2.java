package de.test;

import javax.ejb.Stateful;
import javax.ejb.Stateless;
import javax.jws.WebService;

/**
 * Session Bean implementation class SB2
 */
@Stateless
@WebService
public class SB2 implements SB2Remote {

	private String testState;
	
    /**
     * Default constructor. 
     */
    public SB2() {
        // TODO Auto-generated constructor stub
    }

    public void setState(String state) {
    	testState = state;
    }
    
    public String getState() {
    	return testState;
    }
    
}
