package de.test;

import java.util.Random;

import javax.ejb.Stateless;
import javax.jws.WebService;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import de.test.entities.JPAEntity;

/**
 * Session Bean implementation class SessionBeanBizLogic
 */
@Stateless
@WebService
public class SessionBeanBizLogic implements SessionBeanBizLogicRemote {

	@PersistenceContext
	private EntityManager entityManager;
	
    /**
     * Default constructor. 
     */
    public SessionBeanBizLogic() {
        // TODO Auto-generated constructor stub
    }
    public String sayHello() {
    	
    	JPAEntity j = new JPAEntity();
    	Random r = new Random();
    	int id = r.nextInt();
    	j.setId(id);
    	j.setField("f");
		entityManager.persist(j);
		entityManager.flush(); // Flush to update Object and receive it with his new ID
		
		JPAEntity j2 = entityManager.find(JPAEntity.class, 1);
        return j2.getField();
    }
}
