package de.test;

import javax.ejb.Remote;

@Remote
public interface SB2Remote extends SB {

	public String getState();
	public void setState(String state);
	
}
