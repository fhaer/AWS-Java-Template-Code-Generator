package de.test.bizlogic;

import javax.ejb.Stateless;

import de.test.BizLogicBeanRemote;

/**
 * Session Bean implementation class BizLogicBean
 */
@Stateless
public class BizLogicBean implements BizLogicBeanRemote {

    /**
     * Default constructor. 
     */
    public BizLogicBean() {
        // TODO Auto-generated constructor stub
    }

	@Override
	public String sayHello() {
		return "Hello";
	}

}
